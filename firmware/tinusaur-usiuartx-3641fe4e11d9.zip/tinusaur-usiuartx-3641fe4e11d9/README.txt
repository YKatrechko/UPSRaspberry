USIUARTX - USI as UART in half-duplex mode for tinyAVR microcontrollers.

-----------------------------------------------------------------------------------
 Copyright (c) 2016 Neven Boyanov, Tinusaur Team. All Rights Reserved.
 Distributed as open source software under MIT License, see LICENSE.txt file.
 Please, as a favor, retain the link http://tinusaur.org to The Tinusaur Project.
-----------------------------------------------------------------------------------

USIUARTX is written in plain C and, in most cases, requires few additional libraries.


==== Links ====

Official Tinusaur Project website: http://tinusaur.org
Project USIUARTX page: http://tinusaur.org/projects/usiuartx/
Project USIUARTX source code: https://bitbucket.org/tinusaur/usiuartx

Twitter: https://twitter.com/tinusaur
Facebook: https://www.facebook.com/tinusaur

