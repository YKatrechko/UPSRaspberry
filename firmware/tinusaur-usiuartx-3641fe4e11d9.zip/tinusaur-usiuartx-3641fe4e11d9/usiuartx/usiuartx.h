/*
 * USIUARTX - USI as UART in half-duplex mode
 *
 * @created: 2015-03-23
 * @author: Neven Boyanov
 *
 * Source code available at: https://bitbucket.org/tinusaur/usiuartx
 *
 */

#ifndef USIUARTX_H
#define USIUARTX_H

// ============================================================================

#include <stdint.h>

#include <avr/io.h>

// #include "../owowod/owowod.h"
// #include "../owowod/debugging.h"

// ============================================================================

// REF: AVR307 Half Duplex UART Using the USI Module on tinyAVR and megaAVR devices

//********** USI UART Defines **********//

//#define SYSTEM_CLOCK    14745600
//#define SYSTEM_CLOCK    11059200
//#define SYSTEM_CLOCK     8000000
//#define SYSTEM_CLOCK     7372800
//#define SYSTEM_CLOCK     3686400
//#define SYSTEM_CLOCK     2000000
//#define SYSTEM_CLOCK     1843200
#define SYSTEM_CLOCK     1000000

//#define BAUDRATE 115200
//#define BAUDRATE  57600
//#define BAUDRATE  28800
//#define BAUDRATE  19200
//#define BAUDRATE  14400
#define BAUDRATE   9600

#define TIMER_PRESCALER  1
//#define TIMER_PRESCALER  8

// Transmit and Receive buffer size
// Must be power of 2, i.e. 2,4,8,16,32,64,128,256
#define USIUARTX_RX_BUFFER_SIZE        32
#define USIUARTX_TX_BUFFER_SIZE        32

// ----------------------------------------------------------------------------

//********** USI_UART Prototypes **********//

void usiuartx_init(void);

uint8_t usiuartx_tx_has_data(void);
void usiuartx_tx_byte(uint8_t);
void usiuartx_tx_string(char *);

void usiuartx_rx_init(void);
uint8_t usiuartx_rx_has_data(void);
uint8_t usiuartx_rx_byte(void);

// ============================================================================

#endif
